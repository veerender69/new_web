import React, { useState, useEffect } from 'react';
import data from './components/back/Data/Data';
import Header from './components/front/Header/Header';
import { BrowserRouter as Router } from 'react-router-dom';
import Routes from './components/front/Routes/Routes';

const App = () => {
  const { productItems } = data;
  const [cartItems, setCartItems] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const storedUserLoggedInInformation = localStorage.getItem('isLoggedIn');
    if (storedUserLoggedInInformation === '1') {
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, []);

  const handleAddProduct = (product) => {
    const ProductExist = cartItems.find((item) => item.id === product.id);
    if (ProductExist) {
      setCartItems(
        cartItems.map((item) =>
          item.id === product.id
            ? { ...ProductExist, quantity: ProductExist.quantity }
            : item
        )
      );
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1 }]);
    }
  };
  const handleRemoveProduct = (productToRemove) => {
    setCartItems(cartItems.filter((product) => product !== productToRemove));
  };

  const handleCartClear = () => {
    setCartItems([]);
  };

  return (
    <div>
      <Router>
        <Header cartItems={cartItems} isLoggedIn={isLoggedIn} />
        <Routes
          productItems={productItems}
          cartItems={cartItems}
          handleAddProduct={handleAddProduct}
          handleRemoveProduct={handleRemoveProduct}
          handleCartClear={handleCartClear}
          click={isLoggedIn}
          loggedIn={setIsLoggedIn}
        />
      </Router>
    </div>
  );
};

export default App;
