import Aws from './assets/download.jpg'
import Rjs from './assets/reactjs.jpg'
import C from './assets/c.png'

const data={
    productItems:[
        {
            id:'1',
            name:'React',
            price:499,
            image:Rjs
        },
        {
            id:'2',
            name:'AWS',
            price:699,
            image:Aws
        },
        {
            id:'3',
            name:'C',
            price:599,
            image:C
            
        },
        
    ]
}

export default data