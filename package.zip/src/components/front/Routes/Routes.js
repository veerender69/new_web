import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Products from '../Products/Products';
import Login from '../Login/Login';
import Cart from '../Cart/Cart';
import PageNotFound from '../Page Not Found/PageNotFound';
import Logout from '../Logout/Logout';
import Checkout from '../Cart/Checkout';
import Business from '../Business/Busines';
import Teach from '../Teach/Teach';
import Payment from '../Cart/Payment';
import Player from '../Player/Player';

const Routes = ({
  productItems,
  cartItems,
  handleAddProduct,
  handleRemoveProduct,
  handleCartClear,
  click,
  loggedIn,
}) => {
  return (
    <div>
      <Switch>
        {click ? (
          <div>
            <Route path='/courses' exact>
              <Products
                productItems={productItems}
                handleAddProduct={handleAddProduct}
              />
            </Route>
            <Route path='/logout' exact>
              <Logout isLoggedIn={click} loggedIn={loggedIn} />
            </Route>
            <Route path='/checkout' exact>
              <Checkout />
            </Route>
            <Route path='/payment' exact>
              <Payment />
            </Route>
            <Route path='/business' exact>
              <Business />
            </Route>
            <Route path='/teach' exact>
              <Teach />
            </Route>
            <Route path='/player' exact>
              <Player />
            </Route>
            <Route path='/cart' exact>
              <Cart
                cartItems={cartItems}
                handleRemoveProduct={handleRemoveProduct}
                handleCartClear={handleCartClear}
              />
            </Route>
          </div>
        ) : (
          <div>
            <Route path='/' exact>
              <Login isLoggedIn={click} loggedIn={loggedIn} />
            </Route>
            <Route path='/login' exact>
              <Login isLoggedIn={click} loggedIn={loggedIn} />
            </Route>
          </div>
        )}
        <Route component={PageNotFound}></Route>
      </Switch>
    </div>
  );
};

export default Routes;
