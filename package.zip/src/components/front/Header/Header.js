import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = (props) => {
  return (
    <header className='header'>
      {props.isLoggedIn ? (
        <>
          <div>
            <h1>
              <Link to='/' className='logo'>
                U
              </Link>
            </h1>
          </div>
          <div className='header-links'>
            <ul>
              <li>
                <Link to='/courses'>Courses</Link>
              </li>
              <li>
                <Link to='/teach'>Teach</Link>
              </li>
              <li>
                <Link to='/business'>Business</Link>
              </li>
            </ul>
            <ul>
              <li>
                  <Link to='/logout'>Logout</Link>
              </li>
            </ul>
            <ul>
              <li>
                <Link to='/cart' className='cart'>
                  <span>Cart</span>
                  <span className='cart-length'>
                    {props.cartItems.length === 0 ? '' : props.cartItems.length}
                  </span>
                </Link>
              </li>
            </ul>
          </div>
        </>
      ) : (
        <div className='header-links'>
          <div>
            <h1>
              <Link to='/' className='logo'>
                U
              </Link>
            </h1>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
