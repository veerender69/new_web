import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

import classes from './Login.module.css';
import Button from '../../FormElements/Button';
import Card from '../../FormElements/Card';
import Input from '../../FormElements/Input';

const Login = (props) => {
  const [enteredUsername, setEnteredUsername] = useState('');
  const [enteredPassword, setEnteredPassword] = useState('');
  const [errors, setErrors] = useState('');

  const name = 'root';
  const pass = 'root';

  let history = useHistory();

  const onSubmitHandler = (event) => {
    event.preventDefault();
    if (enteredUsername === name && enteredPassword === pass) {
      console.log(props.isLoggedIn);
      localStorage.setItem('isLoggedIn', '1');
      props.loggedIn(true);
      history.push('/courses');
    } else if (enteredUsername !== name) {
      setErrors('Invalid username');
    } else if (enteredPassword !== pass) {
      setErrors('Invalid password');
    }
  };

  const onUsernameChangeHandler = (event) => {
    setEnteredUsername(event.target.value);
  };

  const onPasswordChangeHandler = (event) => {
    setEnteredPassword(event.target.value);
  };

  return (
    <Card>
      <form onSubmit={onSubmitHandler} className={classes.input}>
        <label className={classes.login}>Log In</label>
        <div className={classes.error}>
          {errors !== '' ? <div>{errors}</div> : ''}
        </div>
        <label htmlFor='username'>Username</label>
        <Input
          id='username'
          type='text'
          // isValid={setIsValid}
          value={enteredUsername}
          onChange={onUsernameChangeHandler}
        ></Input>
        <label htmlFor='password'>Password</label>
        <Input
          id='password'
          type='password'
          // isValid={setIsValid}
          value={enteredPassword}
          onChange={onPasswordChangeHandler}
        ></Input>
        <Button type='submit'>LogIn</Button>
      </form>
    </Card>
  );
};

export default Login;
