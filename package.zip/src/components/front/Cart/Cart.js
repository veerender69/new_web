import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import './Cart.css';
import Checkout from './Checkout';


const Cart = (props) => {
  const [cartIsEmpty, setCartIsEmpty] = useState(false);
  const totalPrice = props.cartItems.reduce(
    (price, item) => price + item.quantity * item.price,
    0
  );

  useEffect(() => {
    if (props.cartItems.length === 0) {
      setCartIsEmpty(true);
    } else {
      setCartIsEmpty(false);
    }
  }, [props.cartItems.length]);

  let his = useHistory();

  const checkoutHandler = () => {
    console.log('checkout');
    his.push('/checkout');
  };

  return (
    <div className='cart-items'>
      <h2 className='cart-items-header'>Cart Items</h2>
      <div className='clear-cart'>
        {props.cartItems.length >= 1 && (
          <button className='clear-cart-button' onClick={props.handleCartClear}>
            Clear Cart
          </button>
        )}
      </div>

      {props.cartItems.length === 0 && (
        <div className='cart-items-empty'>Cart is Empty....</div>
      )}
      <div>
        {props.cartItems.map((item) => (
          <div key={item.id} className='cart-items-list'>
            <img
              className='cart-items-image'
              src={item.image}
              alt={item.name}
            />
            <div className='cart-items-name'>{item.name}</div>
            <div className='cart-items-function'>
              <button
                className='cart-items-remove'
                onClick={() => props.handleRemoveProduct(item)}
              >
                Remove
              </button>
            </div>
            <div className='cart-items-price'>
              {item.quantity}*RS{item.price}
            </div>
          </div>
        ))}
      </div>
      <div className='cart-items-total-price-name'>
        Total price
        <div className='cart-items-total-price'>RS{totalPrice}</div>
      </div>
      <div className='checkout'>
        {cartIsEmpty ? '' : <button onClick={checkoutHandler}>Checkout</button>}
      </div>
    </div>
  );
};

export default Cart;
