import React from 'react'
import { Link } from "react-router-dom";

const Payment = () => {
    return (
        <div>
            <h1>Payment is Successful</h1>
            <p>Press here for Course page</p>
        <Link className="btn btn-info" to="/courses">
          Courses
        </Link>
        </div>
    )
}

export default Payment
