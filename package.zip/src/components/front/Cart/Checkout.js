import React,{useState} from 'react'
import { useForm } from "react-hook-form";
import { useHistory } from 'react-router-dom';

const Checkout = () => {
  const {register,handleSubmit,formState: { errors },reset,trigger} = useForm();

  const [expireMonth, setExpireMonth] = useState('');
  const [expireYear, setExpireYear] = useState('');

  const handleExpMonth = (e) => {
    setExpireMonth(e.target.value);
 }
  const handleExpYear = (e) => {
    setExpireYear(e.target.value);
  }

  let his = useHistory();

  const onSubmit = (data) => {
    console.log(data);
    his.push('/payment');

  };

  return (
    <div className="container pt-5">
          <h1 className="text-center pt-3 text-secondary">Payment Form</h1>
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group">
              <label className="col-form-label">Name on Card</label>
              <input
                type="text"
                className={`form-control ${errors.name && "invalid"}`}
                {...register("name", { required: "Name is Required" })}
                onKeyUp={() => {
                  trigger("name");
                }}
              />
              {errors.name && (
                <small className="text-danger">{errors.name.message}</small>
              )}
            </div>
            <div className="form-group">
              <label className="col-form-label">Card Number</label>
              <input
                type="text"
                className={`form-control ${errors.cardnumber && "invalid"}`}
                {...register("cardnumber", {
                  required: "Card Number is Required",
                  pattern: {
                    value: /^[0-9]*$/,
                    message: "Only numbers are allowed",
                  }
                })}
                onKeyUp={() => {
                  trigger("cardnumber");
                }}
              />
              {errors.cardnumber && (
                <small className="text-danger">{errors.cardnumber.message}</small>
              )}
            </div>
            <div className="input-grp">
                <div className="input-container">
                     <h5>Expiration Year</h5>
                     <select value={expireYear} onChange={handleExpYear}>
                       <option value="January">January</option>
                       <option value="February">February</option>
                       <option value="March">March</option>
                       <option value="April">April</option>
                       <option value="May">May</option>
                       <option value="June">June</option>
                       <option value="July">July</option>
                       <option value="August">August</option>
                       <option value="September">September</option>
                       <option value="October">October</option>
                       <option value="November">November</option>
                       <option value="December">December</option>
                     </select>
                 </div>
                 <div className="input-container">
                 <h5>Expiration Month</h5>
                 <select value={expireMonth} onChange={handleExpMonth}>
                       <option value="2021">2021</option>
                       <option value="2022">2022</option>
                       <option value="2023">2023</option>
                       <option value="2024">2024</option>
                       <option value="2025">2025</option>
                       <option value="2026">2026</option>
                       <option value="2027">2027</option>
                       <option value="2028">2028</option>
                       <option value="2029">2029</option>
                     </select>
                 </div>
                 <div className="form-group">
              <label className="col-form-label">CVV</label>
              <input
                type="password"
                className={`form-control ${errors.cvv && "invalid"}`}
                {...register("cvv", {
                  required: "CVV Number is Required",
                  pattern: {
                    value: /^[0-9]*$/,
                    message: "Only numbers are allowed",
                  }
                })}
                onKeyUp={() => {
                  trigger("cvv");
                }}
              />
              {errors.cvv && (
                <small className="text-danger">{errors.cvv.message}</small>
              )}
            </div>
             </div>
            <input
              type="submit"
              className="btn btn-primary my-3"
              value={`Pay`}
            />
          </form>
        </div>
  );
}

export default Checkout




















