import React from 'react'
import './Player.css'
import ReactPlayer from 'react-player'

const Player = () => {
    return (
        <div className='Player'>
            <ReactPlayer 
            controls 
            width='480px' 
            height='240px' 
            url='https://www.youtube.com/watch?v=THL1OPn72vo'
            onReady={()=>console.log('Ready')}
            onStart={()=>console.log('Start')}
            onPause={()=>console.log('Pause')}
            onEnded={()=>console.log('Ended')}
            onError={()=>console.log('Error')}
            />
        </div>
    )
}

export default Player
