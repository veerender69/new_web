import { useHistory } from 'react-router-dom';

const Logout = (props) => {
  let history = useHistory();
  const handleClick = () => {
    console.log(props.isLoggedIn);
    if (props.isLoggedIn) {
      localStorage.removeItem('isLoggedIn');
      props.loggedIn(false);
      history.push('/login');
    }
  };

  return (
    <div>
      <h1>Do you want to Logout ?</h1>
      <button onClick={handleClick}>Logout</button>
    </div>
  );
};

export default Logout;
